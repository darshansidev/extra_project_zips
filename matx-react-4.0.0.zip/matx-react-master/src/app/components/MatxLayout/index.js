import { lazy } from "react";

export const MatxLayouts = { layout1: lazy(() => import("./Layout1/Layout1")) };
