export const mainThemes = ["purple1", "purple2", "blue", "purpleDark1", "purpleDark2", "blueDark"];

export const mainSidebarThemes = [
  "whitePurple",
  "whiteBlue",
  "slateDark1",
  "slateDark2",
  "purpleDark1",
  "purpleDark2",
  "blueDark"
];

export const topbarThemes = [
  "whitePurple",
  "whiteBlue",
  "slateDark1",
  "slateDark2",
  "purpleDark1",
  "purpleDark2",
  "blueDark"
];
