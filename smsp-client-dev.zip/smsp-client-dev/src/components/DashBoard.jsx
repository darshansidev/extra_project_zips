import React from 'react'

const DashBoard = () => {
    return (
        <div>
            Dashboard
        </div>
    )
}

export default DashBoard
