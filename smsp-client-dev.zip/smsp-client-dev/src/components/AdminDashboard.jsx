import React, { useEffect, useState } from 'react'

const AdminDashboard = () => {
    const [user, setUser] = useState();

    useEffect(() => {
        const storedUserData = localStorage.getItem('userData');
        if (storedUserData) {
            const parsedUserData = JSON.parse(storedUserData);
            setUser(parsedUserData);
        }
    }, []);
    return (
        <div>
            Admin panel dashboard
            {console.log(user)}
        </div>
    )
}

export default AdminDashboard
