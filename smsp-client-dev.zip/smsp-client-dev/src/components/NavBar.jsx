import React, { useEffect, useState } from 'react';
import { Navbar, Nav, Container } from 'react-bootstrap';
import { Link, useLocation } from 'react-router-dom';
import Cookies from "js-cookie";

const NavBar = () => {
    const location = useLocation();
    const [userType, setUserType] = useState(null);
    const [tokenData, setTokenData] = useState('');

    // Function to determine if a link should be shown based on current location and module
    const showLink = (module) => {
        return !location.pathname.includes(module.toLowerCase());
    };

    useEffect(() => {
        const storedUserData = localStorage.getItem('userData');
        const token = Cookies.get('Authorization');
        if (storedUserData) {
            const parsedUserData = JSON.parse(storedUserData);
            setUserType(parsedUserData.userType);
            setTokenData(token)
        }
    }, []);

    return (
        <Navbar bg="dark" variant="dark" expand="lg">
            <Container>
                <Navbar.Brand as={Link} to="/">SMSP System</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="mr-auto">
                        {tokenData ? (
                            <>
                                {userType === 'Admin' && (
                                    <>
                                        {showLink('admin') && <Nav.Link as={Link} to="/admin">Admin Home</Nav.Link>}
                                        {showLink('user') && <Nav.Link as={Link} to="/user">User</Nav.Link>}
                                        {showLink('tentative') && <Nav.Link as={Link} to="/tentative">Tentative</Nav.Link>}
                                        {showLink('owner') && <Nav.Link as={Link} to="/owner">Owner</Nav.Link>}
                                    </>
                                )}
                                {userType === 'Tentative' && (
                                    <>
                                        {showLink('tentative') && <Nav.Link as={Link} to="/tentative">Tentative Home</Nav.Link>}
                                        {showLink('user') && <Nav.Link as={Link} to="/user">User</Nav.Link>}
                                        {showLink('admin') && <Nav.Link as={Link} to="/admin">Admin</Nav.Link>}
                                        {showLink('owner') && <Nav.Link as={Link} to="/owner">Owner</Nav.Link>}
                                    </>
                                )}
                                {userType === 'Owner' && (
                                    <>
                                        {showLink('owner') && <Nav.Link as={Link} to="/owner">Owner Home</Nav.Link>}
                                        {showLink('user') && <Nav.Link as={Link} to="/user">User</Nav.Link>}
                                        {showLink('admin') && <Nav.Link as={Link} to="/admin">Admin</Nav.Link>}
                                        {showLink('tentative') && <Nav.Link as={Link} to="/tentative">Tentative</Nav.Link>}
                                    </>
                                )}
                            </>
                        ) : (
                            <>
                                {showLink('user') && <Nav.Link as={Link} to="auth/login">SignIn</Nav.Link>}
                                {showLink('admin') && <Nav.Link as={Link} to="auth/signup">SignUp</Nav.Link>}
                            </>
                        )}
                    </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    );
}

export default NavBar;
