import React from 'react'
import { Outlet } from 'react-router-dom'
import NavBar from './NavBar'
import { useSelector } from 'react-redux';

const RootLayout = () => {
    const user = useSelector(state => state.auth.user);
    const userData = user?.data.user;
    return (
        <>
            <NavBar userData={userData} />
            <div>
                <main>
                    <Outlet />
                </main>
            </div>
        </>
    )
}

export default RootLayout
