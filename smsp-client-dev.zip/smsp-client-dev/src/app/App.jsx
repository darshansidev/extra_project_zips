import AdminDashboard from '../components/AdminDashboard';
import DashBoard from '../components/DashBoard';
import RootLayout from '../components/RootLayout';
import SignIn from '../pages/auth/signIn/SignIn';
import SignUp from '../pages/auth/signUp/SignUp';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import { createBrowserRouter, createRoutesFromElements, Route, RouterProvider } from "react-router-dom";

function App() {
  const router = createBrowserRouter(createRoutesFromElements(
    <Route path='/' element={<RootLayout />}>
      <Route index element={<DashBoard />}></Route>
      <Route path='/auth/login' element={<SignIn />}></Route>
      <Route path='/auth/signup' element={<SignUp />}></Route>
      <Route path='/admin-dashboard' element={<AdminDashboard />}></Route>
    </Route>
  ))
  return (
    <div className="App">
      <RouterProvider router={router} />
    </div>
  );
}

export default App;
