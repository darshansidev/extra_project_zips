import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import './signUp.css'
import { signup } from '../../../features/auth/authSlice';

const SignUp = () => {
    const dispatch = useDispatch();
    const loading = useSelector(state => state.auth.loading);
    const error = useSelector(state => state.auth.error);

    const [formData, setFormData] = useState({
        fullName: '',
        contactNo: '',
        email: '',
        password: '',
        photoProof: null,
    });

    const handleChange = event => {
        const { name, value } = event.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value,
        }));
    };

    const handleFileChange = event => {
        const file = event.target.files[0];
        setFormData(prevState => ({
            ...prevState,
            photoProof: file,
        }));
    };

    const handleSubmit = event => {
        event.preventDefault();
        const { fullName, contactNo, email, password, photoProof } = formData;
        const userData = new FormData();
        userData.append('fullName', fullName);
        userData.append('contactNo', contactNo);
        userData.append('email', email);
        userData.append('password', password);
        userData.append('photoProof', photoProof);
        dispatch(signup(userData));
    };

    return (
        <div className="main-container background-image">
            <div className="main-content">
                <div className="gif-container">
                    <div className="local-gif">
                        <img src="https://i.gifer.com/5Bg2.gif" alt="GIF" />
                    </div>
                </div>
                <h2 className="text-center mb-4 text-white">SignUp</h2>
                {loading && <p>Loading...</p>}
                {error && <p>{error}</p>}
                <form onSubmit={handleSubmit}>
                    <div className="mb-3">
                        <label htmlFor="fullName" className="form-label text-white">Full Name</label>
                        <input type="text" name="fullName" className="form-control" id="fullName" required onChange={handleChange} />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="contactNo" className="form-label text-white">Phone No</label>
                        <input type="number" name="contactNo" className="form-control" id="contactNo" required onChange={handleChange} />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="exampleInputEmail1" className="form-label text-white">Email address</label>
                        <input type="email" name="email" className="form-control" id="exampleInputEmail1" required onChange={handleChange} />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="exampleInputPassword1" className="form-label text-white">Password</label>
                        <input type="password" name="password" className="form-control" id="exampleInputPassword1" required onChange={handleChange} />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="photoProof" className="form-label text-white">Id Proof</label>
                        <input type="file" name="photoProof" className="form-control-file" id="photoProof" required onChange={handleFileChange} />
                    </div>
                    <div className="container text-center">
                        <input type="submit" className="btn btn-primary form-control text-white" value="Signup" />
                    </div>
                </form>
            </div>
        </div>
    )
}

export default SignUp
