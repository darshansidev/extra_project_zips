import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { login } from '../../../features/auth/authSlice';
import Cookies from 'js-cookie';
import './signIn.css';

const SignIn = () => {
    const dispatch = useDispatch();
    const loading = useSelector(state => state.auth.loading);
    const error = useSelector(state => state.auth.error);
    const user = useSelector(state => state.auth.user);

    const [formData, setFormData] = useState({
        email: '',
        password: '',
    });

    const handleChange = event => {
        const { name, value } = event.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value,
        }));
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        const { email, password } = formData;
        dispatch(login({ email, password }));
    };

    useEffect(() => {
        if (user && user.data && user.data.token) {
            const authToken = user.data.token.token;
            try {
                Cookies.set('Authorization', authToken, { expires: 1 });
                
                localStorage.setItem('userData', JSON.stringify(user.data.user));
                window.location.href = '/admin-dashboard';
            } catch (error) {
                console.error('Error occurred while setting authToken:', error);
            }
        }
    }, [user]);

    return (
        <div className="main-container login-image">
            <div className="main-content">
                <div className="gif-container">
                    <div className="signup-gif">
                        <img src="https://i.gifer.com/5Bg2.gif" alt="Signup GIF" />
                    </div>
                </div>
                <h2 className="text-center mb-4 text-white">SignIn</h2>
                {error && <p className="text-center text-danger">{error}</p>}
                <form onSubmit={handleSubmit}>
                    <div className="mb-3">
                        <label htmlFor="exampleInputEmail1" className="form-label text-white">Email address</label>
                        <input type="email" name="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required onChange={handleChange} />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="exampleInputPassword1" className="form-label text-white">Password</label>
                        <input name="password" type="password" className="form-control" id="exampleInputPassword1" required onChange={handleChange} />
                    </div>
                    <div className="container text-center">
                        <input type="submit" className="btn btn-primary form-control text-white" value="Login" disabled={loading} />
                    </div>
                </form>
            </div>
        </div>
    );
}

export default SignIn;


// import React, { useState, useEffect } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import { login } from '../../../features/auth/authSlice';
// import Cookies from 'js-cookie';
// import './signIn.css';

// const SignIn = () => {
//     const dispatch = useDispatch();
//     const loading = useSelector(state => state.auth.loading);
//     const error = useSelector(state => state.auth.error);
//     const user = useSelector(state => state.auth.user);

//     const [formData, setFormData] = useState({
//         email: '',
//         password: '',
//     });

//     const handleChange = event => {
//         const { name, value } = event.target;
//         setFormData(prevState => ({
//             ...prevState,
//             [name]: value,
//         }));
//     };

//     const handleSubmit = async (event) => {
//         event.preventDefault();
//         const { email, password } = formData;
//         dispatch(login({ email, password }));
//     };

//     useEffect(() => {
//         if (user && user.data && user.data.token) {
//             const authToken = user.data.token.token;
//             try {
//                 Cookies.set('Authorization', authToken, { expires: 1 });
//                 window.location.href = '/admin-dashboard';
//             } catch (error) {
//                 console.error('Error occurred while setting authToken:', error);
//             }
//         }
//     }, [user]);

//     return (
//         <div className="main-container login-image">
//             <div className="main-content">
//                 <div className="gif-container">
//                     <div className="signup-gif">
//                         <img src="https://i.gifer.com/5Bg2.gif" alt="Signup GIF" />
//                     </div>
//                 </div>
//                 <h2 className="text-center mb-4 text-white">SignIn</h2>
//                 {error && <p className="text-center text-danger">{error}</p>}
//                 <form onSubmit={handleSubmit}>
//                     <div className="mb-3">
//                         <label htmlFor="exampleInputEmail1" className="form-label text-white">Email address</label>
//                         <input type="email" name="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required onChange={handleChange} />
//                     </div>
//                     <div className="mb-3">
//                         <label htmlFor="exampleInputPassword1" className="form-label text-white">Password</label>
//                         <input name="password" type="password" className="form-control" id="exampleInputPassword1" required onChange={handleChange} />
//                     </div>
//                     <div className="container text-center">
//                         <input type="submit" className="btn btn-primary form-control text-white" value="Login" disabled={loading} />
//                     </div>
//                 </form>
//             </div>
//         </div>
//     );
// }

// export default SignIn;




// import React, { useState } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import { login } from '../../../features/auth/authSlice';
// import Cookies from 'js-cookie';
// import './signIn.css'
// // import { Link } from 'react-router-dom';


// const SignIn = () => {
//     const dispatch = useDispatch();
//     const loading = useSelector(state => state.auth.loading);
//     const error = useSelector(state => state.auth.error);
//     const user = useSelector(state => state.auth.user);

//     const [formData, setFormData] = useState({
//         email: '',
//         password: '',
//     });

//     const handleChange = event => {
//         const { name, value } = event.target;
//         setFormData(prevState => ({
//             ...prevState,
//             [name]: value,
//         }));
//     };

//     const handleSubmit = async (event) => {
//         event.preventDefault();
//         const { email, password } = formData;
//         dispatch(login({ email, password }));

//         const authToken = await user.data.token.token;
//         Cookies.set('Authorization', authToken, { expires: 1 });
//     };

//     return (
//         <div className="main-container login-image">
//             <div className="main-content">
//                 <div className="gif-container">
//                     <div className="signup-gif">
//                         <img src="https://i.gifer.com/5Bg2.gif" alt="Signup GIF" />
//                     </div>
//                 </div>
//                 <h2 className="text-center mb-4 text-white">SignIn</h2>
//                 {loading && <p>Loading...</p>}
//                 {error && <p>{error}</p>}
//                 <form onSubmit={handleSubmit}>
//                     <div className="mb-3">
//                         <label htmlFor="exampleInputEmail1" className="form-label text-white">Email address</label>
//                         <input type="email" name="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required onChange={handleChange} />
//                     </div>
//                     <div className="mb-3">
//                         <label htmlFor="exampleInputPassword1" className="form-label text-white">Password</label>
//                         <input name="password" type="password" className="form-control" id="exampleInputPassword1" required onChange={handleChange} />
//                     </div>
//                     <div className="container text-center">
//                         <input type="submit" className="btn btn-primary form-control text-white" value="Login" />
//                     </div>
//                 </form>
//             </div>
//         </div>

//     );
// }

// export default SignIn;



